package com.globalsoftwaresupport;

public class Constants {

	private Constants() {
		
	}
	
	public static final String ALPHABET = " ABCDEFGHIJKLMNOPQRSTUVWXYZ";
}
